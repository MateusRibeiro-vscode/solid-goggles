package Atividades.internas;

import Atividades.internas.Casa.Quarto;

public  class Casa {
    private String quantoscomados;

    public Casa(String quantoscomados) {

        this.quantoscomados = quantoscomados;
    }

    class Quarto{
        private String qcama;

        public Quarto(String qcama) {
            this.qcama = qcama;

        }
        void enviar(){
            System.out.println("quantidade de comodos : "+quantoscomados);
            System.out.println("quantidade de cama : "+qcama);
        }
    }


}
class Tcasa{
    static void main(String[] args) {
        Casa c = new Casa("10");
        Casa.Quarto q = c.new Quarto("235");
    q.enviar();
    }
}