package Atividades.internas;

public class Loja {
    private String nome;

    public Loja(String nome) {
        this.nome = nome;
    }

    class Caixa{
        private double qdDinheiro;

        public Caixa(double qdDinheiro) {
            this.qdDinheiro = qdDinheiro;


        }
    public void mensagem(){

        System.out.println("qual o nome da loja"+nome);
        System.out.println("quantidade de dinheiro : "+qdDinheiro);
        }
    }
}

class exLoja{
    static void main(String[] args) {
       Loja l = new Loja(Input.st ("qual o nome da loja"));
        Loja.Caixa c = l.new Caixa(Input.d("qual e quantidade de dinheiro"));
        c.mensagem();
    }
}