package Atividades.local;

public class Printt {
    public void exiber(String texto){
        class Mensagem{
            public void me(){
                System.out.println(texto);

            }
        }
        Mensagem m = new Mensagem();
        m.me();
    }
}
class exxprint{
    static void main(String[] args) {
        Printt p = new Printt();
        p.exiber(Input.st("digita ai "));
    }
}