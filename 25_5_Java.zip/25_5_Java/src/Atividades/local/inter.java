package Atividades.local;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class inter {
    public void perfil(String n){
        class Saldacao{
            public void men(){
                String l = LocalTime.now().getHour()>=6? "bom noite" : "boa dia";
                   System.out.println(l +" "+ n);
            }
        }

    Saldacao s = new Saldacao();
        s.men();
    }
}
class Experfil{
    static void main(String[] args) {
        inter i =new inter();
        i.perfil(Input.st("qual o seu nome"));
    }
}

