package Atividades.concreta;

import java.util.Scanner;

public class Conta {
    private double numero ,saldo;
    Conta (double saldo,double numero){

        this.saldo=saldo;
        this.numero=numero;

    }
    void depositar(){
         System.out.println(saldo+" - " +numero+" = " +(saldo-numero));

    };
}
class Mcon{
    static void main(String[] args) {
        double l ,n;
        System.out.println("saldo: ");
        l=new Scanner(System.in).nextDouble();
        System.out.println("numero: ");
        n=new Scanner(System.in).nextDouble();
        Conta c = new Conta(l,n);
        c.depositar();
    }
}
