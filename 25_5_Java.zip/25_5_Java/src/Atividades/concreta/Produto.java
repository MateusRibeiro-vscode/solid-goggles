package Atividades.concreta;

import java.util.Scanner;

public class Produto {
    private String  nome;
    private double preço;
    Produto(String nome , double preço){
        this.nome=nome;
        this.preço=preço;

    }
    @Override
    public String toString() {
        System.out.println("nome = "+nome+" preco = "+preço);
        return "nome = "+nome+" preco = "+preço;
    }
    void exibirPreco(){
        System.out.println("nome = "+nome+" preco = "+preço);
    }
}
class ExProduto{
    public static void main(String[] args) {


    String l ;
    double n;
        System.out.println("nome: ");
    l=new Scanner(System.in).nextLine();
        System.out.println("preco: ");
    n=new Scanner(System.in).nextDouble();

    Produto p = new Produto(l,n);
    p.exibirPreco();
}}
