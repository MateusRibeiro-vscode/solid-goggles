package Atividades.concreta;

import java.util.Scanner;

class Livro {

    private String titulo,autor;
    Livro(String autor,String titulo){
        this.autor=autor;
        this.titulo=titulo;
    }
    public void mostrarDados(){
        System.out.println("titulo :"+titulo+", autor :"+autor);

    }

    @Override
    public String toString() {
        System.out.println("titulo "+titulo +", autor : "+ autor);
    return "titulo "+titulo +" autor : "+ autor;
    }

}
class MLivro{

   public static void main(String[] args) {
        String a ,t;
        System.out.println("autor: ");
        a=new Scanner(System.in).nextLine();
        System.out.println("titulo: ");
        t=new Scanner(System.in).nextLine();
         Livro l = new Livro(a,t);
    l.mostrarDados();
    }
        }
