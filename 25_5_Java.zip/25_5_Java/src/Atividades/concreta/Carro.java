package Atividades.concreta;

import java.util.Scanner;

public class Carro {
    private String marca,modelo;
    Carro(String marca,String modelo){
        this.marca=marca;
        this.modelo=modelo;
    }
    @Override
    public String toString() {
        System.out.println("marca = "+marca+" modelo = "+modelo);
        return "marca = "+marca+" modelo = "+modelo;
    }
   public  void exibir(){
       System.out.println("marca = "+marca+" modelo = "+modelo);
   }
}
class Carroex{
   public static void main(String[] args) {

        String l ,n;
        System.out.println("marca: ");
        l=new Scanner(System.in).nextLine();
        System.out.println("modelo: ");
        n=new Scanner(System.in).nextLine();
        Carro c = new Carro(l,n);
        c.exibir();
    }
}