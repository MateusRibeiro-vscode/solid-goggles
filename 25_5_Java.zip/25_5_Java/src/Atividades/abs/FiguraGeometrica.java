package Atividades.abs;

public abstract class FiguraGeometrica {
    abstract double calcularArea(double a, double l);


}
class Triangulo extends FiguraGeometrica{

    @Override
    double calcularArea(double a, double l) {
        System.out.println(a*l/2);
        return a*l/2;
    }

}
class ExCalulo{
    public static void main(String[] args) {
        Triangulo t = new Triangulo();
        t.calcularArea(40,200);
    }
}
