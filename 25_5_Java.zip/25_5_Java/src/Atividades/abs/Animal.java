package Atividades.abs;

public abstract class Animal {
    public abstract void  emitirsom();

}
class Cachorro extends Animal{


    @Override
    public void emitirsom() {
        System.out.println("som de cachorro");
    }

}
class aaaaaaa{
   public static void main(String[] args) {
        Cachorro c=new Cachorro();
        c.emitirsom();
    }
}

