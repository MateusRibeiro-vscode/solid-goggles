package Atividades.sealex;

sealed public class Dispositivo permits Notebook , Tablet {
    private String nome,versao;

    public Dispositivo(String nome,String versao) {
        this.nome = nome;
        this.versao = versao;
    }
    public void mendem(){
        System.out.println("qual o nome do dispositivo"+nome);
        System.out.println("qual e a  verçao "+versao);
    }
}
final class Notebook extends Dispositivo{
    private String teclado;
    public Notebook(String nome, String versao,String teclado) {
        super(nome, versao);
        this.teclado=teclado;
    }
    @Override
    public void mendem(){
        super.mendem();
        System.out.println("o seu teclado e "+teclado);
    }

}
final class Tablet extends Dispositivo{
    private String tela;
    public Tablet(String nome, String versao,String tela) {
        super(nome, versao);
        this.tela=tela;
    }
    @Override
    public void mendem(){
        super.mendem();
        System.out.println("a sua tela e "+tela);
    }

}
class Exnoot{
    static void qualtipo(Dispositivo d){
        int i =d.getClass().getName().split("\\.").length-1;
        if (d instanceof Notebook){
            System.out.println("-------------");
            System.out.println("class : "+d.getClass().getName().split("\\.")[i]);
            d.mendem();
            System.out.println("-------------");
            return;
        } else if(d instanceof Tablet){
            System.out.println("-------------");
            System.out.println("class : "+d.getClass().getName().split("\\.")[i]);
            d.mendem();
            System.out.println("-------------");
            return;
        }else {
        System.out.println("-------------");
        System.out.println("class : "+d.getClass().getName().split("\\.")[i]);
        d.mendem();
        System.out.println("-------------");
        return;}
    }

    static void main(String[] args) {
        Dispositivo d = new Dispositivo(Input.st("qual e o nome do dispositivo "),Input.st("qual e a versao do dispositivo "));
        System.out.println("-------------------------------");
        Dispositivo n = new Tablet(Input.st("qual e o nome do Tablet"),Input.st("qual e a versao do Tablet "),Input.st("qual a tela deste tablet"));
        System.out.println("-------------------------------");
        Dispositivo t = new Notebook(Input.st("qual e o nome  do Notebook"),Input.st("qual e a versao do Notebook "),Input.st("Qual o teclado deste nootbook"));
        System.out.println("-------------------------------");
        qualtipo(d);
        qualtipo(n);
        qualtipo(t);
    }
}