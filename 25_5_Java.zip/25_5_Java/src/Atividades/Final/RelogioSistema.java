package Atividades.Final;

import javax.xml.crypto.Data;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;



public class RelogioSistema {
    public  void mostrarHora(){
        System.out.println(LocalTime.now().format(DateTimeFormatter.ofPattern("HH"))+" horas");
    }
}
class eRelogio{
    static void main(String[] args) {
        RelogioSistema r= new RelogioSistema();
        r.mostrarHora();
    }
}