package Atividades.Final;

import java.util.Scanner;

public final class ConfiguracaoSistema {
   public String mostrarVersao(String versao){
       System.out.println("sua versao e ="+versao);
       return versao;
    }
}
class  Testrec{
    public static void main(String[] args) {

        System.out.println("qual a versao do sistema: ");
        Scanner s = new Scanner(System.in);
        ConfiguracaoSistema c = new ConfiguracaoSistema();
        c.mostrarVersao(s.nextLine());
    }
}