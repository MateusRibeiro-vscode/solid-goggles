package Atividades.anonima;

public class Runn implements Runnable{
    @Override
    public void run() {

        //esse metodo e muita daora para treds
        for (int i = 0; i < 100; i++) {
            try {
                Thread.sleep(10000);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        System.out.println("ruun");
        }
    }
}
class ExRun{
    static void main(String[] args) {


    Runnable i=()->{
        for (int l = 0; l < 100; l++) {
            try {
                Thread.sleep(10000);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("seinao");
    }};
    Runn r = new Runn();
    Thread t = new Thread(i,"zoeira");

    Thread td = new Thread(r,"seilaa");


        try {
            Thread.sleep(10000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        t.start();
        td.start();

}}
