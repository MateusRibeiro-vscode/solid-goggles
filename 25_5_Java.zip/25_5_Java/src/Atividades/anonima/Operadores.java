package Atividades.anonima;

public interface Operadores {
    void soma(double a ,double b);
}
class Somais implements Operadores{
    @Override
    public void soma(double a, double b) {
        System.out.println(a+b);
    }

    static void main(String[] args) {
        Somais s = new Somais();
        s.soma(Input.d("qual o primeiro numero"),Input.d("qual o segumdo numero"));
    }
}
