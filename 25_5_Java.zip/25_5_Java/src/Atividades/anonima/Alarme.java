package Atividades.anonima;

public interface Alarme {
    void tocar();
}
class Chamado implements Alarme{

    @Override
    public void tocar() {
        System.out.println("tuctuctuc");
    }
}
class ExChamado {
    static void main(String[] args) {
        Chamado c = new Chamado();
        c.tocar();
    }
}