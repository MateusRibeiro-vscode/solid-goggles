package Atividades.enun;

public enum MesAno {
    JANEIRO,FEVEREIRO,MARCO;
}
 class C{
     static void main(String[] args) {
         System.out.println(MesAno.FEVEREIRO);
     }
        }

