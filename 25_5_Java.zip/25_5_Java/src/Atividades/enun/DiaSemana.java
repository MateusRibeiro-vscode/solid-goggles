package Atividades.enun;

public enum DiaSemana {
    sabadoi(7),
    domingo(1),
    segunda(2),
    terca(3),
    quarta(4),
    quinta(5),
    sexta(6),
    ;

    int i;
     DiaSemana(int i){
         this.i=i;;

    }

}
class Exdiase{
    static void main(String[] args) {

        System.out.println( DiaSemana.domingo);
    }
}
