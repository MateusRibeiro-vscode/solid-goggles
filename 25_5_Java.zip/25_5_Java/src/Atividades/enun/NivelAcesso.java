package Atividades.enun;

public enum NivelAcesso {
    GERENCIA,FUNCIONARIO,CLIENTE;
}
class Exnivel{
    static void main(String[] args) {
        System.out.println(NivelAcesso.CLIENTE);
    }
}

