package classsscom;

public class Relatorio {

    public void getar(String l){

        class Cabesalho{

            private String titulo;

            public Cabesalho(String titulo) {

                this.titulo = titulo;

            }

            public void mostrar(){

                System.out.println (titulo);

            }

        }

        Cabesalho c = new Cabesalho(l);

        c.mostrar();

    }

}
class Inprima{

    static void main(String[] args) {

         Relatorio r = new Relatorio();
        r.getar("aaa");

    }

}
