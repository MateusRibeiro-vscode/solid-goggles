package classsscom;

public class  Empresa {

    static class Departamento{

        private String nome;

     public Departamento(String nome){
         this.nome=nome;
     }
     public void mostrar (){
         System.out.println("name depatarmento : "+nome);
     }

    }

}
class Tentarerrar{

    static void main(String[] args) {
        Empresa.Departamento e = new Empresa.Departamento("conspiraçao");
        e.mostrar();
    }
}
