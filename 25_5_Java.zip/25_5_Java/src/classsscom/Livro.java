package classsscom;

public class Livro {
   private String titulo,autor;
   Livro(String titulo ,String autor){
       this.titulo=titulo;
       this.autor = autor;
   }

    @Override
    public String toString() {
        return "titulo: "+titulo +"\n"+"autor: "+autor ;

    }
   public <t> void mensagem(){
       t titulo= (t) this.titulo;
       t autor= (t) this.autor;
       System.out.println("titulo: "+titulo +"\n"+"autor: "+autor );

   }
}
class ma{
    static void main(String[] args) {
        Livro l = new Livro("arte sem guerra","sem tsu");
        System.out.println(l);
        System.out.println("-------------");
        l.mensagem();
    }
}
