package Exemplo;

class Coputador {

    private String marca ;
    Coputador(String marca){
        this.marca=marca;
    }
    public class Processador {
        private String modelo;

        Processador(String modelo) {
            this.modelo = modelo;
        }

        public void mostrarDados() {
            System.out.println("Marca do computador: " + marca);
            System.out.println("Modelo do processador: " + modelo);
        }
    }
    }

class men{
    static void main(String[] args) {


    Coputador c = new Coputador("azus");
   // c.Processador ca=new c.Processador("5.5090");
    Coputador.Processador praa = c.new Processador("5059-9");

    praa.mostrarDados();
}}
