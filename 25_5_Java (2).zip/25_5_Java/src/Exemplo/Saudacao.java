package Exemplo;

public interface Saudacao {
    public void ola(String nome);



}
class Anonima /**implements Saudacao**/{
    static void main(String[] args) {


    Saudacao a = new Saudacao() {
        @Override
        public void ola(String nome) {
            System.out.println(nome+" ola prazer em conhecer");
        }

    };
    a.ola("enzo");

}}
