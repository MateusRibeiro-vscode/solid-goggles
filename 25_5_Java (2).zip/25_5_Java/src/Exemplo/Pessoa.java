package Exemplo;

record Aluno(String nome, int idade) {
public Aluno {
if (idade < 0 || idade>110) {
throw new IllegalArgumentException("Idade não pode ser negativa.");
}


}
}
class Mensagem {
static void main(String[] args) {
Aluno a = new Aluno("enzo", 160);
System.out.println("Nome: " + a.nome());
System.out.println("Idade: " + a.idade());
System.out.println(a);
}}
