package Exemplo;

 public final class Matematicoo {
     public int somar(int a, int b) {
         System.out.println(a+b);
         return a + b;
     }


 }
class mansagem /**extends  Matematicoo**/{


    static void main(String[] args) {
        Matematicoo m = new Matematicoo();
       m.somar(10,90);
    }
}