package Atividades.Exercicio6;

public class Valida {
    public void validando(double n1){
         class  validand{
         public void num(){
             System.out.println(n1>=0 ? "o numero e positivo "+n1 :"o numero e negativo "+n1);

         }

        }
    validand v=new validand();
         v.num();

    }
}
class Exvalida{

   static Valida[][] va = new Valida[1][];

    static void main(String[] args) {
        va[0]=new Valida[3];
        for (int i=0;i<va[0].length;i++){
        va[0][i]= new Valida();;
        va[0][i].validando(Input.d("digite um numero"));

    }}
}