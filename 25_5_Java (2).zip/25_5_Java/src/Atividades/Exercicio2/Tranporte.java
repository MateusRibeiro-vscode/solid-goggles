package Atividades.Exercicio2;

public abstract class Tranporte {
    abstract String mover();
}
class onibus extends Tranporte{
    @Override
    String mover(){
        System.out.println("roda movendo roda movendo onibus movendo");
        return "roda movendo roda movendo onibus movendo";
    }
}
class ETranporte{
    public static void main(String[] args) {
        onibus o = new onibus();
        o.mover();

    }
}
