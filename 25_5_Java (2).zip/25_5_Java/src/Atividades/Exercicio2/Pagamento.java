package Atividades.Exercicio2;

public abstract class Pagamento {
    public abstract String processar();
}
class TPagamento extends Pagamento{

    @Override
    public String processar() {
        System.out.println("funcionaaaa");
        return "funcionA";
    }
}

   class A{
      public static void main(String[] args) {
           TPagamento tp=new TPagamento();
           tp.processar();
       }
   }
