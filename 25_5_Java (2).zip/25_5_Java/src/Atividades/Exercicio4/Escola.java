package Atividades.Exercicio4;

import java.util.Scanner;

public class Escola {
  private String nome;

    public Escola(String nome) {
        this.nome = nome;
    }

    class Turma{
        private  String nomeT;

        public Turma(String nomeT) {
            this.nomeT = nomeT;
        }
        public void enviar(){
        System.out.printf("nome da escola $s \n ",nome +"nome da turma : $s",nomeT);

    }


    }
}
class Exescola{

    public static  <t> t input(String titulo,t pa ){
        ;
    System.out.println(titulo + " : ");
    Scanner s = new Scanner(System.in);
    if (pa instanceof String){

        String l=  s.nextLine();
        return ((t)l);
    }
    if (pa instanceof Double){
            Double l=  s.nextDouble();
        return (((t) l) );
    }
        if (pa instanceof Integer){
            Integer l=  s.nextInt();
            return ((t) l);
        }
        return (t) "";
    }

    static void main(String[] args) {

        String a = input("qual e a sua escola : ","");
       String b =  input("qual e a sua turma : ","");
        Escola e = new Escola(a);
        Escola.Turma t= e.new Turma(b);
        t.enviar();
    }
}
