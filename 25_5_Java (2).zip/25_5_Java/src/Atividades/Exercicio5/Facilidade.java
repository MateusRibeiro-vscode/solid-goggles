package Atividades.Exercicio5;
// eu to bricando nessa o object ele ja extendido automaticamente
public class Facilidade extends Object{
    private String l;

    public Facilidade(String l) {
        this.l = l;
    }

    @Override
    public String toString() {

        return l;
    }
}
class Outra{
    static void main(String[] args) {
        Facilidade f = new Facilidade(Input.st("digite qualquer coisa "));
        System.out.println(f);
    }
}
