package Atividades.Exercicio5;

import java.util.Scanner;

class Input {






      public static String st() {

          Scanner s = new Scanner(System.in);
          String l = s.nextLine();
      return l;
      }

    public static double d() {

        Scanner s = new Scanner(System.in);
        Double l = s.nextDouble();
        return l;
      }
    public static int i() {

        Scanner s = new Scanner(System.in);
        Integer l = s.nextInt();
           return l;
    }
    public static String st(String titulo) {
        System.out.println(titulo + " : ");
        Scanner s = new Scanner(System.in);
        String l = s.nextLine();
        return l;
    }

    public static double d(String titulo) {
        System.out.println(titulo + " : ");
        Scanner s = new Scanner(System.in);
        Double l = s.nextDouble();
        return l;
    }
    public static int i(String titulo) {
        System.out.println(titulo + " : ");
        Scanner s = new Scanner(System.in);
        Integer l = s.nextInt();
        return l;
    }

}
