package Atividades.Exercicio5;

public interface Impressao {
   void inprimir(String s);
}
class Epson implements Impressao{

    @Override
    public void inprimir(String s) {
        System.out.println(s);
    }
}
class Exin{
    static void main(String[] args) {
        Epson e = new Epson();
        e.inprimir(Input.st("qual vai ser a inpresao"));
    }
}
