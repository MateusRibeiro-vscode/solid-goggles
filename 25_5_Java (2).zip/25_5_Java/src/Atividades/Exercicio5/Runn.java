package Atividades.Exercicio5;

public class Runn implements Runnable{

        @Override
        public void run() {
            System.out.println("seinao");
        }
    }


class ExRun{
    static void main(String[] args) {



    Runn r = new Runn();
    r.run();

}}
