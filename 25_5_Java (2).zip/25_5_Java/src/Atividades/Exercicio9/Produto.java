package Atividades.Exercicio9;

public record Produto(String nome,double preco) {
    public Produto{

    }
}
class exP{
    static void main(String[] args) {
        Produto p = new Produto(Input.st("qual o nome do preduto"),Input.d("qualo preço do produto"));
        System.out.println("nome " + p.nome());
        System.out.println("preco "+p.preco());
        System.out.println(p);
    }
}
