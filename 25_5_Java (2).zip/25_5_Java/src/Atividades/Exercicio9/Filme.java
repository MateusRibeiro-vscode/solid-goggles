package Atividades.Exercicio9;

public record Filme(String titulo, int ano) {
    public Filme{

    }
}
class  ExFilme{
    static void main(String[] args) {
        Filme f =new Filme(Input.st("qual o titulo"),Input.i("qual o ano"));
        System.out.println("o titulo e "+f.titulo());
        System.out.println("o ano e "+f.ano());
        System.out.println(f);
    }
}
