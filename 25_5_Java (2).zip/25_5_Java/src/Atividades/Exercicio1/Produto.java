package Atividades.Exercicio1;

import java.util.Scanner;

public class Produto {
    private String  nome;
    private double preco;
    Produto(String nome , double preco){
        this.nome=nome;
        this.preco=preco;

    }
    @Override
    public String toString() {
        System.out.println("nome = "+nome+" preco = "+preco);
        return "nome = "+nome+" preco = "+preco;
    }
    void exibirPreco(){
        System.out.println("nome = "+nome+" preco = "+preco);
    }
}
class ExProduto{
    public static void main(String[] args) {


    String l ;
    double n;
        System.out.println("nome: ");
    l=new Scanner(System.in).nextLine();
        System.out.println("preco: ");
    n= new Scanner(System.in).nextDouble();

    Produto p = new Produto(l,n);
    p.exibirPreco();
}}
