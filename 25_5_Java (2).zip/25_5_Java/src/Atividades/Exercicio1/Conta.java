package Atividades.Exercicio1;

import java.util.Scanner;

public class Conta {
    private double numero ,saldo;
    Conta (double saldo,double numero){

        this.saldo=saldo;
        this.numero=numero;

    }
    void depositar(){
         System.out.println(saldo+" - " +numero+" = " +(saldo-numero));

    };
}
class Mcon{
    static void main(String[] args) {
        double l ,n;
        System.out.println("Digite o saldo da sua conta: ");
        l=new Scanner(System.in).nextDouble();
        System.out.println("Eu voce que tira quando da sua conta: ");
        n=new Scanner(System.in).nextDouble();
        Conta c = new Conta(l,n);
        c.depositar();
    }
}
