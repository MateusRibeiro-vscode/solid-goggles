package Atividades.Exercicio10;

sealed public class Forma permits Circulo,Quadrado {
    void area(){
        System.out.println("nao a area");
    }
}
final class  Circulo extends Forma{
    @Override
        void area(){
        System.out.println("2P x raio");
    }
}
final class  Quadrado extends Forma{
    @Override
    void area(){
        System.out.println("base x altura");
    }
}
class exForma{
    static void main(String[] args) {
        Forma q = new Quadrado();
        q.area();
    }
}

