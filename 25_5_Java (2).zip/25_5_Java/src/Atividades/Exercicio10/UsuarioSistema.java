package Atividades.Exercicio10;

sealed public class UsuarioSistema permits Administrador , Cliente {
    void Usuar(){
        System.out.println("UsuarioSistema");
    }
}
final class Administrador extends UsuarioSistema{
    @Override
    void Usuar(){
        System.out.println("adm");
    }
}

final class Cliente extends UsuarioSistema{
    @Override
    void Usuar(){
        System.out.println("client");
    }
}
class Exusuariosis{
    static  UsuarioSistema a = new Administrador();

    static void main(String[] args) {
        a.Usuar();
    }
}

