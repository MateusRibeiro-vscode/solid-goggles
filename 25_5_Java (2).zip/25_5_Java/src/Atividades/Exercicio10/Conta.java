package Atividades.Exercicio10;

sealed public class Conta permits ContaCorrente ,ContaPoupanca{
    void dinheiro(){
        System.out.println("tem dinheiro");
    }

}
final class ContaCorrente extends Conta{
    @Override
    void dinheiro(){
        System.out.println("direiro corremdo");}
}
final class ContaPoupanca extends Conta{
    @Override
    void dinheiro(){
        System.out.println("dinheiro ta poupado");
    }
}
class aaaaaaa{
    static void main(String[] args) {
        Conta c = new ContaCorrente();
        c.dinheiro();
    }
}

