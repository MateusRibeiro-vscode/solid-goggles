package Atividades.Exercicio7;

public class Universidade {
    private static  String nome;

    public Universidade(String nome) {

        this.nome = nome;
    }
    static class  Curso{
        private String ncurso;

        public Curso(String ncurso) {
            this.ncurso = ncurso;
        }
        public void men(){
            System.out.println("o nome da universidade e : "+nome);
            System.out.println("o nome do curso e : "+ncurso);
        }
    }
}
class exuni{
    static void main(String[] args) {
        Universidade u = new Universidade(Input.st("qual o nome da universidade e "));
        Universidade.Curso c= new Universidade.Curso(Input.st("qual o nome do curso e"));
        c.men();
    }
}
