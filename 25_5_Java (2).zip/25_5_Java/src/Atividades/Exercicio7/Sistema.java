package Atividades.Exercicio7;

public class Sistema {
    static  class  Log{
       private double num ;

        public Log(double num) {
            this.num = Math.log( num);
        }
   public void men(){
       System.out.println("log =="+num);
   }
    }

}
class exsistem{
    static void main(String[] args) {
        Sistema.Log l= new Sistema.Log(Input.d("escolha um numero"));
    l.men();
    }
}
