package Atividades.Exercicio7;

public class EmpresaTI {
    static class  Setor{
        public void mensagem(){
            System.out.println("setor seila");
        }
    }
}
class exEpesa{
    static void main(String[] args) {

    EmpresaTI.Setor l =new  EmpresaTI.Setor();
    l.mensagem();
}}
