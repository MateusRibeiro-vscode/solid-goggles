package Atividades.Exercicio8;

public enum NivelAcesso {
    GERENCIA,FUNCIONARIO,CLIENTE;
}
class Exnivel{
    static void main(String[] args) {
        System.out.println(NivelAcesso.CLIENTE);
    }
}

