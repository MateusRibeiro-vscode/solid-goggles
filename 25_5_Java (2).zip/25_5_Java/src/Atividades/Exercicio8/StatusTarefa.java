package Atividades.Exercicio8;

public enum StatusTarefa {
    PRONTO,NAOPRONTO,MEDIO;
}
class ExStatus{
    static void main(String[] args) {
        System.out.println(StatusTarefa.MEDIO);
    }
}
