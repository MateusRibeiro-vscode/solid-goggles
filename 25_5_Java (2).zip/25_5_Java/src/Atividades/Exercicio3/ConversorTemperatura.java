package Atividades.Exercicio3;

import java.util.Scanner;

public final class ConversorTemperatura {
    public double celsiusParaFahrenheit(double c){
        System.out.printf("temperatura em celsios %.4f%n ",c);
        System.out.println("sua temperatura em fahrenheit "+(c+273));
        return c+273;
    }
}
class EConversorTemperatura{
    static void main(String[] args) {

        System.out.println("qual temperatura em celsio: ");
    Scanner s = new Scanner(System.in);
    double sa = s.nextDouble();
    ConversorTemperatura c = new ConversorTemperatura();
    c.celsiusParaFahrenheit(sa);
}}

