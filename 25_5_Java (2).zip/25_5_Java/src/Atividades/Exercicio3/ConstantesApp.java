package Atividades.Exercicio3;

import java.util.Scanner;

public final class ConstantesApp {
    public String mostrarNomeSistema(String nome ){
        System.out.println("sua nome do sistema e ="+nome);
        return nome;
    }
}
class  TConstatesapp{
    public static void main(String[] args) {

        System.out.println("qual a nome do sistema: ");
        Scanner s = new Scanner(System.in);

        ConstantesApp c = new ConstantesApp();
        c.mostrarNomeSistema(s.nextLine());
    }}